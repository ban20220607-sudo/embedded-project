unsigned int delay_cnt;
unsigned int adc_value;
unsigned char ultra_done = 0;

const unsigned long FOSC_HZ = 20000000UL;

void delay_loop(unsigned int n)
{
    for (delay_cnt = 0; delay_cnt < n; delay_cnt++) { }
}

void ADC_Init()
{
    ADCON0 = 0x01;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char channel)
{
    unsigned int result;

    if (channel > 7) return 0;

    ADCON0 &= 0xC5;
    ADCON0 |= (channel << 3);

    delay_loop(2);

    ADCON0 |= 0x04;
    while (ADCON0 & 0x02);

    result = ((unsigned int)ADRESH << 8) | ADRESL;
    return result;
}

void pwm_setup()
{
    PR2   = 124;
    T2CON = 0x05;

    CCP1CON = 0x0C;
    CCP2CON = 0x0C;

    CCPR1L = 0;
    CCPR2L = 0;
}

void stop_motors()
{
    PORTB &= 0xC9;
    CCPR1L = 0;
    CCPR2L = 0;
}

void Forward()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 70;
    CCPR2L = 73;
}

void Left()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 35;
    CCPR2L = 75;
}

void Right()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 75;
    CCPR2L = 35;
}

void SharpLeft()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 0;
    CCPR2L = 72;
}

void SharpRight()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 72;
    CCPR2L = 0;
}

char IR_Direction()
{
    unsigned char ir = PORTD & 0x0C;

    if (ir == 0x0C)      return 'T';
    else if (ir == 0x08) return 'R';
    else if (ir == 0x04) return 'L';
    else                 return 'F';
}

void Timer1_Load_10ms()
{
    unsigned int preload = 65536 - 6250;

    TMR1H = preload >> 8;
    TMR1L = preload & 0xFF;
}

void Wait_3sec_Sharp()
{
    unsigned int ticks = 0;

    T1CON = 0x31;
    Timer1_Load_10ms();
    PIR1 &= 0xFE;

    while (ticks < 110)
    {
        while ((PIR1 & 0x01) == 0);
        PIR1 &= 0xFE;
        Timer1_Load_10ms();
        ticks++;
    }

    T1CON &= 0xFE;
}

void main()
{
    char dir;
    unsigned int threshold = 600;

    TRISB = 0x00;
    TRISC = 0xF9;
    TRISD = 0x0C;
    TRISA = 0x01;

    PORTB = 0x00;
    PORTD = 0x00;

    pwm_setup();
    ADC_Init();

    stop_motors();
    PORTD &= ~0x10;
    PORTD &= ~0x20;

    Wait_3sec_Sharp();
    PORTD |= 0x10;

    while (1)
    {
        adc_value = ADC_Read(0);

        if (adc_value < threshold)
            PORTD |= 0x20;
        else
            PORTD &= ~0x20;

        dir = IR_Direction();

        if (dir == 'T')
        {
            stop_motors();
            delay_loop(600);

            SharpLeft();
            delay_loop(900);

            Forward();
            delay_loop(600);

            if (ultra_done)
            {
                stop_motors();
                PORTD |= 0x20;
                PORTB &= ~0x80;
                delay_loop(5000);
                PORTD &= ~0x20;
            }

            continue;
        }

        if (dir == 'L')      Left();
        else if (dir == 'R') Right();
        else                 Forward();

        delay_loop(15);
    }
}