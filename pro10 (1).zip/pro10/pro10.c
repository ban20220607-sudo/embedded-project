unsigned int delay_cnt;
unsigned int adc_value;

void delay_loop(unsigned int n)
{
    for (delay_cnt = 0; delay_cnt < n; delay_cnt++) { }
}

void ADC_Init()
{
    ADCON0 = 0x01;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char channel)
{
    unsigned int result;

    if (channel > 7) return 0;

    ADCON0 &= 0xC5;
    ADCON0 |= (channel << 3);
    delay_loop(2);

    ADCON0 |= 0x04;
    while (ADCON0 & 0x02);

    result = ((unsigned int)ADRESH << 8) | ADRESL;
    return result;
}

void pwm_setup()
{
    PR2   = 124;
    T2CON = 0x05;

    CCP1CON = 0x0C;
    CCP2CON = 0x0C;

    CCPR1L = 0;
    CCPR2L = 0;
}

void stop_motors()
{
    PORTB &= 0xC9;
    CCPR1L = 0;
    CCPR2L = 0;
}

void Forward()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 70;
    CCPR2L = 73;
}

void Left()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 35;
    CCPR2L = 75;
}

void Right()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 75;
    CCPR2L = 35;
}

void SharpLeft()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 0;
    CCPR2L = 80;
}

void SharpRight()
{
    PORTB = (PORTB & 0xC9) | 0x12;
    CCPR1L = 80;
    CCPR2L = 0;
}

char IR_Direction()
{
    unsigned char ir = PORTD & 0x0C;
    if (ir == 0x08)      return 'R';
    else if (ir == 0x04) return 'L';
    else if (ir == 0x0C) return 'T';
    else                 return 'F';
}

void Timer1_Load_10ms()
{
    unsigned int preload = 65536 - 6250;
    TMR1H = preload >> 8;
    TMR1L = preload & 0xFF;
}

void Wait_3sec_Sharp()
{
    unsigned int t = 0;
    T1CON = 0x31;
    Timer1_Load_10ms();
    PIR1 &= ~0x01;

    while (t < 110)
    {
        while ((PIR1 & 0x01) == 0);
        PIR1 &= ~0x01;
        Timer1_Load_10ms();
        t++;
    }

    T1CON &= ~0x01;
}

void Turn_Time_ms(unsigned int ms)
{
    unsigned int ticks = 0;
    unsigned int target = ms / 10;
    if (target == 0) target = 1;

    T1CON = 0x31;
    Timer1_Load_10ms();
    PIR1 &= ~0x01;

    while (ticks < target)
    {
        while ((PIR1 & 0x01) == 0);
        PIR1 &= ~0x01;
        Timer1_Load_10ms();
        ticks++;
    }

    T1CON &= ~0x01;
}

unsigned int Ultrasonic_Read_cm()
{
    unsigned int ticks = 0;

    PORTD &= ~0x01;
    delay_loop(10);

    PORTD |= 0x01;
    delay_loop(60);
    PORTD &= ~0x01;

    TMR1H = 0;
    TMR1L = 0;
    PIR1 &= ~0x01;
    T1CON = 0x11;

    while ((PORTD & 0x02) == 0)
    {
        if (PIR1 & 0x01) { T1CON &= ~0x01; return 0; }
    }

    TMR1H = 0;
    TMR1L = 0;
    PIR1 &= ~0x01;

    while (PORTD & 0x02)
    {
        if (PIR1 & 0x01) { T1CON &= ~0x01; return 0; }
    }

    T1CON &= ~0x01;
    ticks = ((unsigned int)TMR1H << 8) | TMR1L;
    if (ticks == 0) return 0;
    return (ticks / 145);
}

void UltraZone_Step()
{
    unsigned int d = Ultrasonic_Read_cm();

    if (d < 20 && d != 0)
    {
        if (!(PORTD & 0x80) && (PORTD & 0x40)) { SharpRight(); return; }
        if (!(PORTD & 0x40) && (PORTD & 0x80)) { SharpLeft(); return; }

        if (!(PORTC & 0x40) && (PORTC & 0x20)) { Right(); return; }
        if (!(PORTC & 0x20) && (PORTC & 0x40)) { Left(); return; }

        SharpRight();
        return;
    }

    Forward();
}

void main()
{
    char dir;
    unsigned int threshold = 600;
    unsigned char phase = 0;
    unsigned char i;

    TRISB = 0x00;
    TRISC = 0x00;
    TRISC |= 0x60;
    TRISD = 0xCE;
    TRISD &= ~0x01;
    TRISA = 0x01;

    PORTB = 0x00;
    PORTD = 0x00;

    pwm_setup();
    ADC_Init();
    stop_motors();

    PORTD &= ~0x20;
    PORTD &= ~0x10;
    PORTD &= ~0x01;
    PORTB &= ~0x80;

    Wait_3sec_Sharp();
    PORTD |= 0x10;

    while (1)
    {
        adc_value = ADC_Read(0);

        if (adc_value < threshold) PORTD |= 0x20;
        else                       PORTD &= ~0x20;

        dir = IR_Direction();

        if (dir == 'T')
        {
            stop_motors();
            Turn_Time_ms(100);
            SharpLeft();
            Turn_Time_ms(200);
            continue;
        }

        if ((PORTD & 0x20) == 0 && phase < 2)
        {
            UltraZone_Step();

            if ((PORTD & 0x0C) != 0x00) phase = 2;
            continue;
        }

        if (phase == 2)
        {
            if ((PORTD & 0x0C) == 0x0C)
            {
                SharpRight();
                Turn_Time_ms(300);
                stop_motors();

                for (i = 0; i < 40; i++)
                {
                    PORTB |= 0x80;
                    delay_loop(12000);
                    PORTB &= ~0x80;
                    delay_loop(90000);
                }

                PORTD &= ~0x10;
                phase = 3;
                continue;
            }

            if (dir == 'L')      Left();
            else if (dir == 'R') Right();
            else                 Forward();

            continue;
        }

        if (phase == 3) stop_motors();

        if (phase == 0)
        {
            if (dir == 'L')      Left();
            else if (dir == 'R') Right();
            else                 Forward();
        }
    }
}
